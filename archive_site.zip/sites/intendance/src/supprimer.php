<?php

  error_reporting(E_ALL);
  ini_set("display_errors", "1");
  try{
      $pdo = new PDO("sqlite:../database/data.db");
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }
  catch(PDOException $e){}

if(isset($_GET["id"]) && $_GET["id"]>0){
    $pdo->prepare("DELETE FROM Items WHERE id=?")->execute([$_GET["id"]]);
}

header("Location: ../index.php");

?>