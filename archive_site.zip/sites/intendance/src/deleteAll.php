<?php
  error_reporting(E_ALL);
  ini_set("display_errors", "1");
  try{
      $pdo = new PDO("sqlite:../database/data.db");
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }
  catch(PDOException $e){}

$pdo->prepare("DELETE FROM Items WHERE id>0")->execute();
$pdo->prepare("UPDATE sqlite_sequence SET seq=0")->execute();
header("Location: ../index.php");
?>