<?php

require("fpdf.php");

  error_reporting(E_ALL);
  ini_set("display_errors", "1");
  try{
      $pdo = new PDO("sqlite:../database/data.db");
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }
  catch(PDOException $e){}


#$pdf->Ln();

class PDF extends FPDF{
    function Footer(){
        $this->SetY(-15);
        $this->Image("../media/papier_inv.png",0,275,250);
        $this->SetTextColor(255,255,255);
        $this->SetFont("Caveat-Brush","",25);
        $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
    }
}

function head($pdf){
    $pdf->Cell(100, 10, "Nom", 1, 0, "C", true);
    $pdf->Cell(40, 10, "Nombre", 1, 0, "C", true);
    $pdf->Cell(40, 10, "Poids (en g)", 1, 0, "C", true);
    $pdf->Ln();
}

function write($pdf,$line){
    $pdf->Cell(100, 10, $line["name"],1, 0, "C");
    $pdf->Cell(40, 10, $line["number"],1, 0, "C");
    $pdf->Cell(40, 10, $line["weight"],1, 0, "C");
    
    $pdf->Ln();
}

$title="Liste d'intendance";
$mid_x = 100;

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFillColor(0,59,93);
$pdf->AddFont("Sarabun","","Sarabun-Regular.php");
$pdf->AddFont("Caveat-Brush","","CaveatBrush-Regular.php");
$pdf->Image("../media/papier.png",0,0,250);
$pdf->Image("../media/LOGO.png",160,5,40);
$pdf->Image("../media/SGDF_logo_blanc_vertical.png",5,15,40);
$pdf->Image("../media/chemin.png",50,15,100);
$pdf->SetFont("Caveat-Brush","",50);
$pdf->Ln(10);
$pdf->Cell(80);
$pdf->SetTextColor(255,255,255);
$pdf->Cell(25,50,$title,0,0,"C");
$pdf->Ln(70);
$pdf->SetFont("Sarabun","",14);
head($pdf);
$pdf->SetTextColor(0,0,0);
$stmt=$pdo->query("SELECT * FROM Items WHERE id>0 ORDER BY name");
$all=$stmt->fetchAll();
foreach ($all as $line){
    write($pdf,$line);
}
$pdf->output("I");
header("Location: ../index.php");

?>
