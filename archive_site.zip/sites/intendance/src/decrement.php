<?php

 error_reporting(E_ALL);
  ini_set("display_errors", "1");
  try{
      $pdo = new PDO("sqlite:../database/data.db");
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }
  catch(PDOException $e){}

if(isset($_GET["id"]) && $_GET["id"]>0){
    $id=$_GET["id"];
    $stmt = $pdo->prepare("SELECT number FROM Items WHERE id=?");
    $stmt->execute([$id]);
    $res = $stmt->fetch(PDO::FETCH_ASSOC)["number"];
    $res -= 1;
    $l="Location: supprimer.php?id=".$id;
    echo $l;
    if($res <= 0){
        header($l);
        echo "Supprimer";
    }
    else{
        $pdo->prepare("UPDATE Items SET number=? WHERE id=?")->execute([$res,$id]);
        header("Location: ../index.php");
    }
}
else{
    header("Location: ../index.php");
}
?>