<?php
error_reporting(E_ALL);
ini_set("display_errors", "1");
try{
    $pdo = new PDO("sqlite:../database/data.db");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){}


if(isset($_POST["nombre"]) && $_POST["nombre"]!=0 && isset($_POST["nom"]) && $_POST["nom"]!="" && isset($_POST["poids"]) && $_POST["poids"]!=0){
    /*$stmt = $pdo->prepare("SELECT * FROM Items WHERE name=?");
    $stmt->execute([$_POST["nom"]]);
    $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(!$stmt){*/
        $stmt = $pdo->prepare("INSERT INTO Items (name,number,weight) VALUES (?,?,?)");
        $stmt->execute([$_POST["nom"],$_POST["nombre"],$_POST["poids"]]);/*
    }
    else{
        $stmt = $pdo->prepare("SELECT weight FROM Items WHERE name=?")->execute([$_POST["nom"]]);
        $stmt->fetchAll(PDO::FETCH_ASSOC);
        $a=0;
        foreach ($stmt as $line){
            if($line["weight"]==$_POST["poids"]){
                $a+=1;
            }
        }
        if($a==0){
            $stmt = $pdo->prepare("INSERT INTO Items (name,number,weight) VALUES (?,?,?)");
            $stmt->execute([$_POST["nom"],$_POST["nombre"],$_POST["poids"]]);
            }
            }*/
}



header("Location: ../index.php");
?>