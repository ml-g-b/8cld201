<?php
  error_reporting(E_ALL);
  ini_set("display_errors", "1");
  try{
      $pdo = new PDO("sqlite:database/data.db");
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }
  catch(PDOException $e){}
  
?>
<!DOCTYPE html>
<!--

 CREATION : 

 SUBJECT : 

-->
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="icon/cochon.png" type="image/x-icon/">
    <link rel="stylesheet" href="css/style.css">
    <title>Intendance</title>
  </head>
  <body>
    <h1>Création de liste</h1>
    <form method="POST" action="src/add.php">
      <fieldset>
        <legend>Ajouter des aliments</legend>
        <input name="nom" type="text" placeholder="Ajouter ingrédient"><input name="nombre" type="number" placeholder="Nombre" min="1"><input name="poids" type="number" placeholder="Poids" min="1"></br>
        <button type="submit">Envoyer</button> 
      </fieldset>
    </form>
    <?php
          $stmt=$pdo->query("SELECT * FROM Items limit 1");
      $array=($stmt->fetchAll(PDO::FETCH_ASSOC));
      $fields=array_keys($array[0]);
      echo "<table><tr>";
      foreach ($fields as $name){
          echo "<th>".ucfirst($name)."</th>";
      }
      echo "<th>Ajouter</th><th>Réduire</th><th>Supprimer</th>";
      echo "</tr>";
      $stmt=$pdo->query("SELECT * FROM Items WHERE id>0 ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
      foreach ($stmt as $line){
          echo "<tr>";
          $id=$line["id"];
          foreach ($line as $data){
              echo "<td>".$data."</td>";
          }
          echo "<td><a href=\"src/increment.php?id=".$id."\">Ajouter</a></td>";
          echo "<td><a href=\"src/decrement.php?id=".$id."\">Enlever</a></td>";
          echo "<td><a href=\"src/supprimer.php?id=".$id."\">Supprimer</a></td>";
          echo "</tr>";
      }
      echo "</table>";
    ?>
    <form class="center" action="src/deleteAll.php">
      <button type="submit">Tout supprimer</button>
    </form>
    <form class="center" action="src/pdf.php">
      <button type="submit">Créer PDF</button>
    </form>
  </body>
<html>
