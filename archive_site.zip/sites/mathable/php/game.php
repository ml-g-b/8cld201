
<?php

 error_reporting(E_ALL);
ini_set("display_errors", "1");
try{
    $pdo = new PDO("sqlite:database/mt.db");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
  catch(PDOException $e){}

  function nature($c){
      $class="";
      switch($c){
      case -2 :
          $class="f2";
          break;
      case -3:
          $class="f3";
          break;
      case -4 :
          $class="plus";
          break;
      case -5:
          $class="fois";
          break;
      case -6:
          $class="moins";
          break;
      case -7 :
          $class="divise";
          break;
      default :
          ;
      }
      return $class;
  }
  
  function create_table_pdo($pdo){
      $stmt=$pdo->query("SELECT * FROM Plateau_base");
      echo "<table>";
      $l=1;
      foreach($stmt as $line){
          echo "<tr id=\"l".$l."\">";
          $p=0;
          foreach($line as $cell){
              if($p%2==0){
                  if($cell<0){
                      echo "<td id=\"l".($l)."-c".($p/2+1)."\" class=\"".nature($cell)."\" onclick=\"click('l".$l."c".($p/2+1)."')\"></td>";
                  }
                  else{
                      if ($cell>=1 && $cell<=4){
                          echo "<td id=\"l".($l)."-c".($p/2+1)."\" onclick=\"click('l".$l."c".($p/2+1)."')\">".$cell."</td>";
                      }
                      else{
                          echo "<td id=\"l".($l)."-c".($p/2+1)."\" onclick=\"click('l".$l."c".($p/2+1)."')\"></td>";
                      }
                  }
              }
              $p++;
          }
          echo "</tr>";
          $l++;
      }
      echo "</table>";
  }
  
  function create_header_table($n){
      echo "<thead>";
      for($i=0 ; $i<$n ; $i++)
          echo "<th></th>";
      echo "</thead>";
  }
  
  function create_table($n){
      echo "<table>";
      for($i=0 ; $i<$n ; $i++){
          echo "<tr id=\"line-".($i+1)."\">";
          for($j=0 ; $j<$n ; $j++){
              echo "<td id=\"cell-".($i+1).($j+1)."\"></td>";
          }
          echo "</tr>";
      }
      echo "</table>";
  }
  
?>
<!DOCTYPE html>
<!--

 CREATION : 

 SUBJECT : 

-->
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>Mathable V1</title>
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div id="game">
      <div id="game_container">
        <?php
             create_table_pdo($pdo);
             //create_table(16);
             ?>
      </div>
      <div id="game_number">
      </div>
    </div>
  </body>
  <script src="js/script.js">
  </script>
<html>
