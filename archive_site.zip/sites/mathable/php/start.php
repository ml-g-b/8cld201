<?php

 error_reporting(E_ALL);
ini_set("display_errors", "1");
try{
    $pdo = new PDO("sqlite:../database/mt.db");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
  catch(PDOException $e){}

echo "J1 : ".$_POST["j1"]." <-> J2 : ".$_POST["j2"]."<br>";
/*
$file_name="../database/Plateau_base.txt";
$file_ptr=fopen($file_name,"r");
if($file_ptr==false)
    echo "Erreur de connexion";

$filesize=filesize($file_name);
$file=fread($file_ptr, $filesize);
fclose($file_ptr);

$doc=explode("\n",$file);
array_shift($doc);
array_pop($doc);

$pdo->prepare("DELETE FROM Plateau_base WHERE column1>-999")->execute();

$value="(?";
for($i=1 ; $i<14 ; $i++){
    $value=$value.",?";
}
$value=$value.")";

foreach($doc as $line){
    $elements=explode(",",$line);
    $sql="INSERT INTO Plateau_base VALUES ".$value;
    $pdo->prepare($sql)->execute($elements);
}

$pdo->prepare("DELETE FROM Sac WHERE id>=0")->execute();

function table($n){
    for($i=3 ; $i<10 ; $i++){
        for($j=1 ; $j<=10 ; $j++){
            if($i*$j==$n)
                return true;
        }
    }
    return false;
}

function number($n){
    if($n>0 && $n<11)
        return 7;
    if(($n>10 && $n<20) || table($n) || $n==0)
        return 1;
    return 0;
}

$array=[];
for($i=0 ; $i<=90 ; $i++){
    $n=number($i);
    $sql="INSERT INTO Sac VALUES (?,?)";
    $pdo->prepare($sql)->execute([$i,$n]);
    if($n>0)
        $array_tmp = array($i => $n);
    $array = $array + $array_tmp;
}

var_dump($array);

$collection1=array_rand($array);

$array[$collection1]=$array[$collection1]-1;
if($array[$collection1]==0)
    unset($array[$collection1]);

$collection2=array_rand($array);
$array[$collection2]=$array[$collection2]-1;
if($array[$collection2]==0)
    unset($array[$collection2]);

echo $collection1." - ".$collection2."<br>";*/

$lien="https://mlgb.fr";

$default_message="<html><head><title>Lien pour accéder à la partie de Mathable</title></head><body><a href=\"".$lien."\">Cliquer ici pour jouer</a></body></html>";

function send_mail($to,$from,$subject,$message){
    $headers='From: Mathable V1-MLGB'."\r\n".'Reply-To: '.$from."\r\n".'X-Mailer: PHP/'.phpversion();
    mail($to,$subject,$message,$headers);
}

echo $_POST["email"];

send_mail($_POST["email"],"contact@mlgb.fr","Partie de Mathable",$default_message);

/*
$key1=array_search($collection1[0]);
$collection2=[array_rand($array)];
echo $collection1[0]." - ".$collection2[0]."<br>";*/
?>