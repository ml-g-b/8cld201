

function click(id){
  //var cell=document.getElementById(id);
  console.log(id);
}