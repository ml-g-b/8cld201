
<?php

 
  
?>
<!DOCTYPE html>
<!--

 CREATION : 

 SUBJECT : 

-->
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>Mathable V1</title>
    <style>
      .center{
      text-align : center;
      }
      form {
        margin : 10px;
        padding : 10px;
      }
      form > *{
        margin : 10px;
        padding : 10px;
        font-size : 25px;
      }
      input{
        height : 50px;
        margin-top : 20px;
        margin-bottom : 20px;
        font-size : 25px;
      }
    </style>
  </head>
  <body>
    <div class="center">
    <form method="POST" action="php/start.php">
      <input type="text" id="j1" name="j1" placeholder="Entrer le nom du 1er joueur" required><br>
      <input type="text" id="j2" name="j2" placeholder="Entrer le nom du 2e joueur" required><input type="mail" name="email" placeholder="Entrer le mail du J2" required><br>
      <button type="submit">Envoyer</button>
    </form>
    </div>
  </body>
<html>
