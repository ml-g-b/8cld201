#!/usr/bin/env bash

sqlite3 mt.db <<EOF 
import Plateau_base.csv Plateau_base;

EOF