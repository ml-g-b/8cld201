LOAD DATA
LOCAL INFILE 'Plateau_base.csv'
INTO TABLE Plateau_base
FIELDS TERMINATED BY ','
OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(column1,column2,column3,column4,column5,column6,column7,column8,column9,column10,column11,column12,column13,column14);
