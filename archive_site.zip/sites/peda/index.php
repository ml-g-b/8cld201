<?php


?>
<!DOCTYPE html>
<!--

 CREATION : 

 SUBJECT : 
 
  -->
<html lang="fr">
  <head>
    <meta charset="utf-8">
      <title>Accueil</title>
      <link rel="stylesheet" href="css/main-style.css">
      <link rel="icon" href="sgdf.ico" type="image/x-icon">
      <style>
      </style>
  </head>
  <body>
    <div class="">
      <div class="choix1" onclick="window.location='src/chef.php'">
        <label class="centerg">Je suis un/une chef</label>
      </div>
      <div class="choix2" onclick="window.location='src/accueil.html'">
        <label class="centerd">Je suis un/une jeune</label>
      </div>
    </div>
  </body>
<html>
