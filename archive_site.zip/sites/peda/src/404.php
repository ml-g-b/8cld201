<?php
  session_start();      
?>
<!DOCTYPE html>
<!--

 CREATION : 

 SUBJECT : 

-->
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>Not found</title>
    <link rel="stylesheet" href="../css/newrole.css">
    <link rel="icon" href="sgdf.ico" type="image/x-icon">
    <title>Not found</title>
    <style>
      h1 {
      position : relative;
      color : #fff;
      font-family : 'Caveat Brush', cursive;
      font-size : 100px;
      top : calc(50% - 200px);
      }
      body{
        text-align : center;
        overflow : hidden;
      }
    </style>
  </head>
  <body>
    <h1>Ressource non trouvée</h1>
  </body>
<html>
