<?php

?>
<!DOCTYPE html>
<!--

 CREATION : 

 SUBJECT : 

-->
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>Wait</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="icon/icon.png" type="image/x-icon">
  </head>
  <body>
    <canvas id="canva" onclick="changeCanvasBg()">
      <img id="image" src="image/croix.png">
    </canvas>
  </body>
  <script src="https://requirejs.org/docs/release/2.3.5/minified/require.js">
  </script>
  <script src="js/scriptTP.js">
  </script>
<html>
